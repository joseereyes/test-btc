
STEP 1: 

Start your db with docker running the following command: docker-compose up -d

STEP 2: 

Install dependencies with node >= 21, run npm install

step 3:

To start the api run npm start and enjoy!


.ENV CONFIG

SERVICE_PORT=8000
DB_NAME=BCT_TEST
DB_USER=root
DB_PASSWORD=root
DB_HOST=localhost
DB_PORT=27018